import UIKit

var str = "Hello, playground"

//declaring datatypes
var randomString = "sdfsdf"
var randomInt = 43
var randomBool = false
var randomDouble = 34.5
var randromFloat = 2.3

let fixedNum = 45

var randomString2: String = "mo"
var randomInt2: Int = 44

//if statement - switch
if randomInt > 3 {
    print("greater than 3")
} else if randomInt2 > 34 {
    
} else {
    
}

//Control flows

//for loop

for _ in 0...2 {
    print("hello")
}

var mobileTech = ["ios", "android", "flutter"]
for item in mobileTech {
    print(item)
}

//while loop
var someNum = 3
while someNum > 3 {
    print("1. greater than 3")
}

repeat {
    //print("2. greater than 3")
} while someNum > 3

func performAddion() {
    _ = 2
    _ = 5
    //print(a+b)
}

performAddion()

func performAddion(arg1 num1: Int, arg2 num2: Int) {
    print(num1 + num2)
}

performAddion(arg1: 25, arg2: 60)

func performAddion(num1: Int, num2: Int) {
    print(num1 + num2)
}

performAddion(num1: 10, num2: 20)

func performAddion(_ num1: Int, _ num2: Int) {
    print(num1 + num2)
}

performAddion(40, 60)

////////////////////////////////////////////////////////////

class Mobile {
    var brand = ""
    var model = ""
}

let mobileObj = Mobile()
mobileObj.brand = "asus"
mobileObj.model = "rog3"
print(mobileObj.brand + " " + mobileObj.model)

//var str1 = "hello"
//var str2 = "world"
//var str3 = "dfsdf"
//print(str1 + " " + str2)
//
//print(str1, str2, str3, separator: "|", terminator: "for")

class Mobile1 {
    var brand = ""
    var model = ""
    
    init(_ brand: String, _ model: String) {
        self.brand = brand
        self.model = model
    }
}

let mobileObj1 = Mobile1("oneplus", "8T pro")
//print(mobileObj1.brand + " ---- " + mobileObj1.model)


class Mobile2 {
    var brand = ""
    var model = ""
    
    //designated init
    init() {
        brand = "nokia"
        model = "lumia"
    }
    
    //convenience init
    convenience init(_ brand: String, _ model: String) {
        self.init()
        self.brand = brand
        self.model = model
    }
}

let mobileObj2 = Mobile2()
print(mobileObj2.brand + " ---- " + mobileObj2.model)

let mobileObj3 = Mobile2("samsung", "S10")
print(mobileObj3.brand + " ---- " + mobileObj3.model)

////////////////////////////////////////////////////////////////////////////////////////////////

class Mobile3 : Mobile2 {
    var price = 0
}

let mobileObj4 = Mobile3()
mobileObj4.model = "sdfs"

////////////////////////////////////////////////////////////////////////////////////////////////

class Mobile4 {
    var brand = ""
    var model = ""
    var protectionType: String?
    
    //designated init
    init() {
        brand = "nokia"
        model = "lumia"
    }
}

let mobileObj5 = Mobile4()
mobileObj5.protectionType = "Gorilla glass 3"
if let protection = mobileObj5.protectionType {
    print(protection)
}

if mobileObj5.protectionType != nil {
    print(mobileObj5.protectionType)
}

let iphone = Mobile4()
iphone.protectionType = "ASdasd"
print(mobileObj5.protectionType!)


