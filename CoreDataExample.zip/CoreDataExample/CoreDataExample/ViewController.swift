//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Shibobrota Das on 23/04/21.
//

import UIKit

class ViewController: UIViewController {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
//        updateCredentials()
//        deleteCredentials()
//        getCredentials()
//        setInitals()
        //Core data
        //Storing multiple information or a list
        getData()
        
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var emailField: UITextField!
    
    private var model = [User]()
    
    
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordField: UITextField!
    
    func setInitals() {
        if model.count > 0 && model[4].email!.count > 0 && model[4].password!.count > 0 {
            emailLabel.text = model[4].email
            passwordLabel.text = model[4].password
        }
    }
    
    @IBAction func submitClick(_ sender: Any) {
        emailLabel.text = emailField.text
        passwordLabel.text = passwordField.text
        let newItem = User(context: context)
        newItem.email = "sankalp@divami.com"
//        updateCredentials()
        setCredentials(email: emailLabel.text!, password: passwordLabel.text!)
    }
    
    func getCredentials() {
        do {
            model = try context.fetch(User.fetchRequest())
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func setCredentials(email: String, password: String) {
        let newUser = User(context: context)
        newUser.email = email
        newUser.password = password
        
        do {
            try context.save()
            getCredentials()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func updateCredentials() {
        do {
            model = try context.fetch(User.fetchRequest())
            for item in model {
                if item.email == "sai@divami.com" {
                    item.email = "pavan@divami.com"
                    item.password = "random"
                }
            }
            try context.save()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func deleteCredentials() {
        do {
            
            model = try context.fetch(User.fetchRequest())
            for item in model {
                if item.email == "pavan@divami.com" {
                    context.delete(item)
                }
            }
            try context.save()
        } catch {
            //cexception
        }
        
    }
    
    func getData() {
        let endPoint = "https://api.sunrise-sunset.org/json?date=2020-01-01&lat=-74.0060&lng=40.7128&formatted=0"
        
        URLSession.shared.dataTask(with: URL(string: endPoint)!, completionHandler: {data, response, error in
            
            if error != nil || data == nil {
                print("error in receiving")
                return
            }
            
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("Error from server")
                return
            }
            
            guard let mime = response.mimeType, mime == "application/json" else {
                print("response format is incorrect")
                return
            }
            
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print(json)
            } catch {
                print("Error in the response is - \(error.localizedDescription)")
            }
        }).resume()
                
    }
}

