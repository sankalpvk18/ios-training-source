//
//  User+CoreDataClass.swift
//  CoreDataExample
//
//  Created by Shibobrota Das on 23/04/21.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
