//
//  SecondViewController.swift
//  NotificationCenterDemo
//
//  Created by Shibobrota Das on 16/04/21.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func twitterBtn(_ sender: Any) {
        NotificationCenter.default.post(name: .twitter, object: nil)
    }
    @IBAction func facebookBtn(_ sender: Any) {
        NotificationCenter.default.post(name: .facebook, object: nil)
    }
}
