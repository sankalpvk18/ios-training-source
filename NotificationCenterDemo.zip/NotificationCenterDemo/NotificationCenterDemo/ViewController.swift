//
//  ViewController.swift
//  NotificationCenterDemo
//
//  Created by Shibobrota Das on 16/04/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(facebook(notification:)), name: .facebook, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(twitter(notification:)), name: .twitter, object: nil)
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    
    @objc func facebook(notification: Notification) {
        lbl.text = "Facebook"
        img.image = #imageLiteral(resourceName: "Facebook-logo")
    }
    
    @objc func twitter(notification: Notification) {
        lbl.text = "Twitter"
        img.image = #imageLiteral(resourceName: "twitter-icon")
    }

    @IBAction func ChooseSocialBtn(_ sender: Any) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    
}

extension Notification.Name {
    static let facebook = Notification.Name("Facebook")
    static let twitter = Notification.Name("Twitter")
}
