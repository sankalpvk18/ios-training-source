//
//  SecondViewController.swift
//  LocalDataPersistence
//
//  Created by Shibobrota Das on 21/04/21.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var textLabel: UILabel!
    var text: String = ""
    
    @IBOutlet weak var textLabel2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let email = UserDefaults.standard.string(forKey: "email")
        let password = UserDefaults.standard.string(forKey: "password")
        print("Email is - \(email!) && password is - \(password!)")
        
        textLabel.text = email!
        textLabel2.text = password!
        
        // Do any additional setup after loading the view.
    }

}
