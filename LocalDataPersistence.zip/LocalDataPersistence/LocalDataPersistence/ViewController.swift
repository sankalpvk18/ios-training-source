//
//  ViewController.swift
//  LocalDataPersistence
//
//  Created by Shibobrota Das on 21/04/21.
//

import UIKit

class ViewController: UIViewController {
    
    struct settings: Codable {
        var color: String
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if let settings = self.getSettings() {
            let colorName = settings.color
            view.backgroundColor = UIColor(named: colorName)
        }
    }
    
    /* passing data between VCs
    1. protocols and delegates
    2. notification center
    3. sharing property
    4. Closures
    5. Usiung Segues*/
    
    /* Local data persistence
    1. User defaults
    2. Property lists or plist
    3. Core data
    4. key chain
    5. SQLite*/
    
    /*  Assingment for next session (using property list):
        Update the color programmatically
        Login data
     */

    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBAction func SendTextClicked(_ sender: Any) {
        
        if emailField.text!.count > 0 || passwordField.text!.count > 0 {
            UserDefaults.standard.set(emailField.text, forKey: "email")
            UserDefaults.standard.set(passwordField.text, forKey: "password")
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func getSettings() -> settings? {
        let decoder = PropertyListDecoder()
        let url = Bundle.main.url(forResource: "Settings", withExtension: "plist")!
        
        if let data = try? Data(contentsOf: url) {
            if let settings = try? decoder.decode(settings.self, from: data) {
                return settings
            }
        }

        return nil
    }
    
}

