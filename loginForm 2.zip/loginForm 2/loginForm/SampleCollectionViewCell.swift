//
//  SampleCollectionViewCell.swift
//  loginForm
//
//  Created by Divami on 07/04/21.
//

import UIKit

class SampleCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var logoImageview: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

}
