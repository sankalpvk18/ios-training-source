//
//  HomeViewController.swift
//  loginForm
//
//  Created by Shibobrota Das on 30/03/21.
//

import UIKit

class HomeViewController: UIViewController {

    @IBAction func NavigateToUIStakViewVC(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "UIStackViewVC") as! UIStackViewVC
        self.navigationController?.pushViewController(vc, animated: false)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func NavigateToUICollectionView(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "SampleCollectionViewController") as! SampleCollectionViewController
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
    @IBAction func NavigateToTableView(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "SampleTableViewController") as! SampleTableViewController
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
}
