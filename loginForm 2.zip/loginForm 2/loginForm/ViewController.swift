//
//  ViewController.swift
//  loginForm
//
//  Created by Shibobrota Das on 30/03/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }

        override func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            navigationController?.setNavigationBarHidden(false, animated: animated)
        }

    @IBOutlet weak var emailTextField: UITextField!
    @IBAction func emailTextField(_ sender: UITextField) {
    }
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBAction func passwordTextField(_ sender: UITextField) {
    }
    
    func setUI() {
        setTextFieldUI(textField: emailTextField)
//        setTextFieldUI(textField: passwordTextField)
    }
    
    func setTextFieldUI(textField: UITextField) {
        textField.layer.cornerRadius = 15.0
        textField.layer.borderWidth = 0.7
        textField.clipsToBounds = true
        textField.setLeftPaddingPoints(10.0)
        textField.setRightPaddingPoints(10.0)
    }
    
    @IBAction func LoginBtnPressed(_ sender: UIButton) {
        print("Email is \(String(describing: emailTextField.text))")
        print("Password is \(String(describing: passwordTextField.text))")
        if !emailTextField.text!.isEmpty && !passwordTextField.text!.isEmpty {
            let vc = self.storyboard?.instantiateViewController(identifier: "HomeViewController") as! HomeViewController
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
}

extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

