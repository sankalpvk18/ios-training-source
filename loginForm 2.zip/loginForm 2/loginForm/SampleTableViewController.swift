//
//  SampleTableViewController.swift
//  loginForm
//
//  Created by Divami on 08/04/21.
//

import UIKit

class SampleTableViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    var fruitsList = ["Banana", "Kiwi", "Watermelon", "Papaya", "Strawberry", "Mango", "Orange", "Pomegranate"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self

        // Do any additional setup after loading the view.
    }

}

extension SampleTableViewController: UITableViewDelegate, UITableViewDataSource {
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruitsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SampleTableViewCell", for: indexPath) as! SampleTableViewCell
        
        cell.cellImageView.image = UIImage(named: fruitsList[indexPath.row].lowercased())
        cell.cellLabel.text = fruitsList[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if(editingStyle == .delete) {
            fruitsList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            print("Fruits list", fruitsList)
        }
        
    }
    
    
}
