//
//  SampleTableViewCell.swift
//  loginForm
//
//  Created by Divami on 08/04/21.
//

import UIKit

class SampleTableViewCell: UITableViewCell {
    
    
    @IBOutlet var cellLabel: UILabel!    
    @IBOutlet var cellImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
